"use strict";
(() => {
  // src/shared/constants.ts
  var STORAGE_KEYS = {
    COMPANY: "scout_company",
    CANDIDATES: "scout_candidates",
    EXTRACTED_PROFILES: "scout_extracted_profiles",
    FIX_RECORDS: "scout_fix_records",
    REPLY_RECORDS: "scout_reply_records",
    CONVERSATIONS: "scout_conversations",
    SELECTED_JOB_OFFER: "scout_selected_job_offer",
    DRY_RUN_MODE: "scout_dry_run_mode",
    DEBUG_LOG_ENABLED: "scout_debug_log_enabled",
    GAS_ENDPOINT: "scout_gas_endpoint",
    GAS_ENABLED: "scout_gas_enabled",
    AUTO_JOB_OFFER: "scout_auto_job_offer",
    API_ENDPOINT: "scout_api_endpoint",
    API_KEY: "scout_api_key",
    CONFIG_CACHE: "scout_config_cache",
    GENERATE_SETTINGS: "scout_generate_settings",
    DETECTION_KEYWORDS: "scout_detection_keywords",
    DEV_MODE: "scout_dev_mode"
  };

  // src/background/service-worker.ts
  chrome.runtime.onInstalled.addListener(async () => {
    const result = await chrome.storage.local.get([STORAGE_KEYS.API_ENDPOINT, STORAGE_KEYS.API_KEY]);
    if (!result[STORAGE_KEYS.API_ENDPOINT]) {
      await chrome.storage.local.set({
        [STORAGE_KEYS.API_ENDPOINT]: "https://scout-api-1080076995871.asia-northeast1.run.app"
      });
    }
    if (!result[STORAGE_KEYS.API_KEY]) {
      await chrome.storage.local.set({
        [STORAGE_KEYS.API_KEY]: "anycare"
      });
    }
  });
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  function isValidSender(sender) {
    return sender.id === chrome.runtime.id;
  }
  async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0] || null;
  }
  async function forwardToContentScript(message) {
    const tab = await getActiveTab();
    if (tab?.id) {
      await chrome.tabs.sendMessage(tab.id, message).catch((err) => {
        console.error("[SW] sendMessage failed:", err);
      });
    }
  }
  async function forwardWithResponse(message, fallbackResponse) {
    const tab = await getActiveTab();
    if (tab?.id) {
      return chrome.tabs.sendMessage(tab.id, message);
    }
    return fallbackResponse;
  }
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (!isValidSender(sender)) {
        console.warn("[SW] Unauthorized message sender:", sender.url);
        return false;
      }
      switch (message.type) {
        case "START_EXTRACTION":
        case "STOP_EXTRACTION": {
          console.log("[SW] Forwarding", message.type, "to content script");
          forwardToContentScript(message);
          sendResponse({ ok: true });
          return false;
        }
        case "FILL_FORM":
        case "FILL_JOB_OFFER": {
          forwardWithResponse(message, { success: false, error: "\u30A2\u30AF\u30C6\u30A3\u30D6\u30BF\u30D6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" }).then(sendResponse);
          return true;
        }
        case "EXTRACT_FACILITY_LIST":
        case "EXTRACT_FACILITY_INFO":
        case "STOP_FACILITY_EXTRACTION":
        case "EXTRACT_JOB_OFFERS": {
          forwardWithResponse(message, { success: false, offers: [], error: "\u30A2\u30AF\u30C6\u30A3\u30D6\u30BF\u30D6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" }).then(sendResponse);
          return true;
        }
        case "GET_OVERLAY_MEMBER_ID": {
          forwardWithResponse(message, { memberId: null }).then(sendResponse);
          return true;
        }
        case "EXTRACT_CONVERSATION":
        case "EXTRACT_ALL_CONVERSATIONS": {
          forwardWithResponse(message, { type: "CONVERSATION_ERROR", error: "\u30A2\u30AF\u30C6\u30A3\u30D6\u30BF\u30D6\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" }).then(sendResponse);
          return true;
        }
        case "START_CONTINUOUS_SEND":
        case "STOP_CONTINUOUS_SEND":
        case "SKIP_CURRENT_CANDIDATE":
        case "RESUME_AFTER_JOB_OFFER":
        case "CONFIRM_RESPONSE": {
          forwardToContentScript(message);
          sendResponse({ ok: true });
          return false;
        }
        case "DETECT_COMPANY": {
          forwardToContentScript(message);
          sendResponse({ ok: true });
          return false;
        }
        case "DEBUG_LOG":
        case "CONFIRM_BEFORE_SEND":
        case "DRY_RUN_COMPLETE":
        case "JOB_OFFER_FAILED":
        case "COMPANY_MISMATCH":
        case "COMPANY_DETECTED":
        case "CONTINUOUS_SEND_COMPLETE": {
          sendResponse({ ok: true });
          return false;
        }
        case "OPEN_SIDE_PANEL": {
          getActiveTab().then(async (tab) => {
            if (tab?.id) {
              await chrome.sidePanel.open({ tabId: tab.id });
            }
          });
          sendResponse({ ok: true });
          return false;
        }
        default:
          return false;
      }
    }
  );
})();
//# sourceMappingURL=service-worker.js.map
