"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // src/shared/constants.ts
  function localTimestamp() {
    const now = /* @__PURE__ */ new Date();
    const off = -now.getTimezoneOffset();
    const sign = off >= 0 ? "+" : "-";
    const hh = String(Math.floor(Math.abs(off) / 60)).padStart(2, "0");
    const mm = String(Math.abs(off) % 60).padStart(2, "0");
    const pad = (n) => String(n).padStart(2, "0");
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}${sign}${hh}:${mm}`;
  }
  var EXTRACTION_INTERVAL_MS, MUTATION_OBSERVER_TIMEOUT_MS, DEFAULT_COMPANY, STORAGE_KEYS, COMPANY_FACILITY_KEYWORDS;
  var init_constants = __esm({
    "src/shared/constants.ts"() {
      "use strict";
      EXTRACTION_INTERVAL_MS = 50;
      MUTATION_OBSERVER_TIMEOUT_MS = 1e4;
      DEFAULT_COMPANY = "ark-visiting-nurse";
      STORAGE_KEYS = {
        COMPANY: "scout_company",
        CANDIDATES: "scout_candidates",
        EXTRACTED_PROFILES: "scout_extracted_profiles",
        FIX_RECORDS: "scout_fix_records",
        REPLY_RECORDS: "scout_reply_records",
        CONVERSATIONS: "scout_conversations",
        SELECTED_JOB_OFFER: "scout_selected_job_offer",
        DRY_RUN_MODE: "scout_dry_run_mode",
        DEBUG_LOG_ENABLED: "scout_debug_log_enabled",
        GAS_ENDPOINT: "scout_gas_endpoint",
        GAS_ENABLED: "scout_gas_enabled",
        AUTO_JOB_OFFER: "scout_auto_job_offer",
        API_ENDPOINT: "scout_api_endpoint",
        API_KEY: "scout_api_key",
        CONFIG_CACHE: "scout_config_cache",
        GENERATE_SETTINGS: "scout_generate_settings",
        DETECTION_KEYWORDS: "scout_detection_keywords",
        DEV_MODE: "scout_dev_mode"
      };
      COMPANY_FACILITY_KEYWORDS = {
        "ark-visiting-nurse": ["\u30A2\u30FC\u30AF", "\u512A\u5E0C"],
        "lcc-visiting-nurse": ["LCC", "\uFF2C\uFF23\uFF23"],
        "ichigo-visiting-nurse": ["\u3044\u3061\u3054"],
        "ichigo-care-home": ["\u3044\u3061\u3054\u306E\u91CC"],
        "chigasaki-tokushukai": ["\u8305\u30F6\u5D0E\u5FB3\u6D32\u4F1A", "\u5FB3\u6D32\u4F1A"],
        "nomura-hospital": ["\u91CE\u6751\u75C5\u9662"],
        "an-visiting-nurse": ["\uFF41\uFF4E\u8A2A\u554F\u770B\u8B77", "an\u8A2A\u554F\u770B\u8B77"]
      };
    }
  });

  // src/shared/storage.ts
  var CONFIG_CACHE_TTL_MS, storage;
  var init_storage = __esm({
    "src/shared/storage.ts"() {
      "use strict";
      init_constants();
      CONFIG_CACHE_TTL_MS = 60 * 60 * 1e3;
      storage = {
        async getCompany() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.COMPANY);
          return result[STORAGE_KEYS.COMPANY] || DEFAULT_COMPANY;
        },
        async setCompany(company) {
          await chrome.storage.local.set({ [STORAGE_KEYS.COMPANY]: company });
        },
        async getCandidates() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.CANDIDATES);
          return result[STORAGE_KEYS.CANDIDATES] || [];
        },
        async setCandidates(candidates) {
          await chrome.storage.local.set({ [STORAGE_KEYS.CANDIDATES]: candidates });
        },
        async updateCandidateStatus(memberId, status) {
          const candidates = await this.getCandidates();
          const index = candidates.findIndex((c) => c.member_id === memberId);
          if (index !== -1) {
            candidates[index].status = status;
            await this.setCandidates(candidates);
          }
        },
        async getExtractedProfiles() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.EXTRACTED_PROFILES);
          return result[STORAGE_KEYS.EXTRACTED_PROFILES] || [];
        },
        async setExtractedProfiles(profiles) {
          await chrome.storage.local.set({ [STORAGE_KEYS.EXTRACTED_PROFILES]: profiles });
        },
        async getFixRecords() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.FIX_RECORDS);
          return result[STORAGE_KEYS.FIX_RECORDS] || [];
        },
        async addFixRecord(record) {
          const records = await this.getFixRecords();
          records.push(record);
          await chrome.storage.local.set({ [STORAGE_KEYS.FIX_RECORDS]: records });
        },
        async clearFixRecords() {
          await chrome.storage.local.remove(STORAGE_KEYS.FIX_RECORDS);
        },
        // --- 返信スカウト記録 ---
        async getReplyRecords() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.REPLY_RECORDS);
          return result[STORAGE_KEYS.REPLY_RECORDS] || [];
        },
        async addReplyRecord(record) {
          const records = await this.getReplyRecords();
          records.push(record);
          await chrome.storage.local.set({ [STORAGE_KEYS.REPLY_RECORDS]: records });
        },
        async clearReplyRecords() {
          await chrome.storage.local.remove(STORAGE_KEYS.REPLY_RECORDS);
        },
        // --- やりとりスレッド ---
        async getConversations() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.CONVERSATIONS);
          return result[STORAGE_KEYS.CONVERSATIONS] || [];
        },
        async addConversation(thread) {
          const threads = await this.getConversations();
          const index = threads.findIndex((t) => t.member_id === thread.member_id);
          if (index !== -1) {
            threads[index] = thread;
          } else {
            threads.push(thread);
          }
          await chrome.storage.local.set({ [STORAGE_KEYS.CONVERSATIONS]: threads });
        },
        async removeConversation(memberId) {
          const threads = await this.getConversations();
          const filtered = threads.filter((t) => t.member_id !== memberId);
          await chrome.storage.local.set({ [STORAGE_KEYS.CONVERSATIONS]: filtered });
        },
        async clearConversations() {
          await chrome.storage.local.remove(STORAGE_KEYS.CONVERSATIONS);
        },
        // --- 選択中の求人 ---
        async getSelectedJobOffer() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.SELECTED_JOB_OFFER);
          return result[STORAGE_KEYS.SELECTED_JOB_OFFER] || null;
        },
        async setSelectedJobOffer(offer) {
          if (offer) {
            await chrome.storage.local.set({ [STORAGE_KEYS.SELECTED_JOB_OFFER]: offer });
          } else {
            await chrome.storage.local.remove(STORAGE_KEYS.SELECTED_JOB_OFFER);
          }
        },
        // --- デバッグ・ドライラン ---
        async isDryRunMode() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.DRY_RUN_MODE);
          return !!result[STORAGE_KEYS.DRY_RUN_MODE];
        },
        async setDryRunMode(enabled) {
          await chrome.storage.local.set({ [STORAGE_KEYS.DRY_RUN_MODE]: enabled });
        },
        async isDebugLogEnabled() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.DEBUG_LOG_ENABLED);
          return !!result[STORAGE_KEYS.DEBUG_LOG_ENABLED];
        },
        async setDebugLogEnabled(enabled) {
          await chrome.storage.local.set({ [STORAGE_KEYS.DEBUG_LOG_ENABLED]: enabled });
        },
        // --- 求人自動選択 ---
        async isAutoJobOfferEnabled() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.AUTO_JOB_OFFER);
          return result[STORAGE_KEYS.AUTO_JOB_OFFER] !== false;
        },
        async setAutoJobOffer(enabled) {
          await chrome.storage.local.set({ [STORAGE_KEYS.AUTO_JOB_OFFER]: enabled });
        },
        // --- GAS連携 ---
        async getGASEndpoint() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.GAS_ENDPOINT);
          return result[STORAGE_KEYS.GAS_ENDPOINT] || "";
        },
        async setGASEndpoint(url) {
          await chrome.storage.local.set({ [STORAGE_KEYS.GAS_ENDPOINT]: url });
        },
        async isGASEnabled() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.GAS_ENABLED);
          return !!result[STORAGE_KEYS.GAS_ENABLED];
        },
        async setGASEnabled(enabled) {
          await chrome.storage.local.set({ [STORAGE_KEYS.GAS_ENABLED]: enabled });
        },
        // --- API設定 ---
        async getAPIEndpoint() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.API_ENDPOINT);
          return result[STORAGE_KEYS.API_ENDPOINT] || "";
        },
        async setAPIEndpoint(url) {
          await chrome.storage.local.set({ [STORAGE_KEYS.API_ENDPOINT]: url });
        },
        async getAPIKey() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.API_KEY);
          return result[STORAGE_KEYS.API_KEY] || "";
        },
        async setAPIKey(key) {
          await chrome.storage.local.set({ [STORAGE_KEYS.API_KEY]: key });
        },
        // --- 設定キャッシュ ---
        async getConfigCache() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.CONFIG_CACHE);
          const cache = result[STORAGE_KEYS.CONFIG_CACHE];
          if (!cache) return null;
          if (Date.now() - cache.timestamp > CONFIG_CACHE_TTL_MS) return null;
          return cache;
        },
        async setConfigCache(cache) {
          await chrome.storage.local.set({ [STORAGE_KEYS.CONFIG_CACHE]: cache });
        },
        // --- 生成設定 ---
        async getGenerateSettings() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.GENERATE_SETTINGS);
          return result[STORAGE_KEYS.GENERATE_SETTINGS] || null;
        },
        async setGenerateSettings(settings) {
          await chrome.storage.local.set({ [STORAGE_KEYS.GENERATE_SETTINGS]: settings });
        },
        // --- 開発者モード ---
        // 有効化すると拡張サイドパネルに「🧪 新パーソナライズ生成」タブが
        // 出現する。通常のオペレーター向けフローはこれに影響されない。
        async getDevMode() {
          const result = await chrome.storage.local.get(STORAGE_KEYS.DEV_MODE);
          return Boolean(result[STORAGE_KEYS.DEV_MODE]);
        },
        async setDevMode(enabled) {
          await chrome.storage.local.set({ [STORAGE_KEYS.DEV_MODE]: enabled });
        },
        async clear() {
          await chrome.storage.local.remove([
            STORAGE_KEYS.CANDIDATES,
            STORAGE_KEYS.EXTRACTED_PROFILES
          ]);
        }
      };
    }
  });

  // src/shared/api-client.ts
  function fetchWithTimeout(url, init, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    return fetch(url, { ...init, signal: controller.signal }).finally(() => clearTimeout(timer));
  }
  async function fetchWithRetry(url, init, timeoutMs, maxRetries = 2) {
    let lastError;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const res = await fetchWithTimeout(url, init, timeoutMs);
        if ((res.status === 502 || res.status === 503 || res.status === 504) && attempt < maxRetries) {
          await new Promise((r) => setTimeout(r, 1e3 * Math.pow(2, attempt)));
          continue;
        }
        return res;
      } catch (e) {
        lastError = e;
        if (attempt < maxRetries) {
          await new Promise((r) => setTimeout(r, 1e3 * Math.pow(2, attempt)));
          continue;
        }
        throw e;
      }
    }
    throw lastError ?? new Error("fetchWithRetry: exhausted retries");
  }
  function formatApiError(status, text) {
    if (status === 429) return "API\u67A0\u8D85\u904E\uFF08\u30EC\u30FC\u30C8\u5236\u9650\uFF09\u3002\u3057\u3070\u3089\u304F\u5F85\u3063\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044";
    if (status === 401) return "API\u30AD\u30FC\u304C\u7121\u52B9\u3067\u3059\u3002\u8A2D\u5B9A\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044";
    if (status === 503) return "\u30B5\u30FC\u30D0\u30FC\u304C\u4E00\u6642\u7684\u306B\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u3057\u3070\u3089\u304F\u5F85\u3063\u3066\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044";
    return `API\u30A8\u30E9\u30FC ${status}: ${text}`;
  }
  var API_TIMEOUT_MS, HEALTH_TIMEOUT_MS, apiClient;
  var init_api_client = __esm({
    "src/shared/api-client.ts"() {
      "use strict";
      init_storage();
      API_TIMEOUT_MS = 18e4;
      HEALTH_TIMEOUT_MS = 1e4;
      apiClient = {
        async getEndpoint() {
          return await storage.getAPIEndpoint();
        },
        async getHeaders() {
          const apiKey = await storage.getAPIKey();
          return {
            "Content-Type": "application/json",
            "X-API-Key": apiKey
          };
        },
        async generate(companyId, profile, options) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithRetry(`${endpoint}/api/v1/generate`, {
            method: "POST",
            headers,
            body: JSON.stringify({ company_id: companyId, profile, options })
          }, API_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async generateBatch(companyId, profiles, options) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithRetry(`${endpoint}/api/v1/generate/batch`, {
            method: "POST",
            headers,
            body: JSON.stringify({
              company_id: companyId,
              profiles,
              options: {
                is_resend: options?.is_resend,
                force_employment: options?.force_employment,
                job_category_filter: options?.job_category_filter
              },
              concurrency: options?.concurrency ?? 10
            })
          }, API_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async getCompanies() {
          const data = await this.getCompaniesWithKeywords();
          return data.map((c) => c.id);
        },
        async getCompaniesWithKeywords() {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(`${endpoint}/api/v1/companies`, {
            method: "GET",
            headers
          }, HEALTH_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          const data = await res.json();
          const companies = data.companies || [];
          if (companies.length > 0 && typeof companies[0] === "string") {
            return companies.map((id) => ({ id, detection_keywords: [], display_name: id }));
          }
          return companies;
        },
        async getCompanyConfig(companyId) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(`${endpoint}/api/v1/companies/${companyId}/config`, {
            method: "GET",
            headers
          }, HEALTH_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async postScoutQuotaSnapshot(companyId, remaining) {
          const endpoint = await this.getEndpoint();
          if (!endpoint) return;
          const headers = await this.getHeaders();
          try {
            await fetchWithTimeout(`${endpoint}/api/v1/admin/scout_quota_snapshot`, {
              method: "POST",
              headers,
              body: JSON.stringify({ company_id: companyId, remaining })
            }, HEALTH_TIMEOUT_MS);
          } catch (err) {
            console.warn("[scout-quota] failed to post snapshot", err);
          }
        },
        async recordManualSend(company, payload) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(`${endpoint}/api/v1/admin/record_manual_send`, {
            method: "POST",
            headers: { ...headers, "Content-Type": "application/json" },
            body: JSON.stringify({ company_id: company, ...payload })
          }, HEALTH_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async syncFixes(company, fixes) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(`${endpoint}/api/v1/admin/sync_fixes`, {
            method: "POST",
            headers: { ...headers, "Content-Type": "application/json" },
            body: JSON.stringify({ company, fixes })
          }, HEALTH_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async syncReplies(company, replies) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(`${endpoint}/api/v1/admin/sync_replies`, {
            method: "POST",
            headers: { ...headers, "Content-Type": "application/json" },
            body: JSON.stringify({ company, replies })
          }, API_TIMEOUT_MS);
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async generatePersonalized(companyId, profile, options) {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(
            `${endpoint}/api/v1/generate/personalized`,
            {
              method: "POST",
              headers: { ...headers, "Content-Type": "application/json" },
              body: JSON.stringify({
                company_id: companyId,
                profile,
                options
              })
            },
            API_TIMEOUT_MS
          );
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async postConversationLogs(company, threads, source = "extension_manual") {
          const endpoint = await this.getEndpoint();
          const headers = await this.getHeaders();
          const res = await fetchWithTimeout(
            `${endpoint}/api/v1/admin/conversation_logs`,
            {
              method: "POST",
              headers: { ...headers, "Content-Type": "application/json" },
              body: JSON.stringify({ company, threads, source })
            },
            HEALTH_TIMEOUT_MS
          );
          if (!res.ok) {
            const text = await res.text();
            throw new Error(formatApiError(res.status, text));
          }
          return res.json();
        },
        async testConnection() {
          try {
            const endpoint = await this.getEndpoint();
            if (!endpoint) {
              return { success: false, error: "API\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093" };
            }
            const apiKey = await storage.getAPIKey();
            if (!apiKey) {
              return { success: false, error: "\u30D1\u30B9\u30EF\u30FC\u30C9\u304C\u8A2D\u5B9A\u3055\u308C\u3066\u3044\u307E\u305B\u3093" };
            }
            const headers = await this.getHeaders();
            const res = await fetchWithTimeout(`${endpoint}/health`, { headers }, HEALTH_TIMEOUT_MS);
            if (res.ok) return { success: true };
            return { success: false, error: `HTTP ${res.status}` };
          } catch (err) {
            if (err instanceof DOMException && err.name === "AbortError") {
              return { success: false, error: "\u63A5\u7D9A\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u3002\u30A8\u30F3\u30C9\u30DD\u30A4\u30F3\u30C8\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044" };
            }
            return { success: false, error: err instanceof Error ? err.message : String(err) };
          }
        }
      };
    }
  });

  // src/content/company-detector.ts
  async function detectCompanyFromPage() {
    let keywordMap = COMPANY_FACILITY_KEYWORDS;
    try {
      const result = await chrome.storage.local.get(STORAGE_KEYS.DETECTION_KEYWORDS);
      const stored = result[STORAGE_KEYS.DETECTION_KEYWORDS];
      if (stored && Object.keys(stored).length > 0) {
        keywordMap = stored;
      }
    } catch {
    }
    const textSources = [];
    textSources.push(document.title);
    const navLinks = document.querySelectorAll("a.c-sub-side-nav__link");
    for (const link of navLinks) {
      textSources.push(link.textContent || "");
    }
    const headers = document.querySelectorAll('h1, h2, .c-breadcrumb, .c-header, .c-header__title, [class*="header"] [class*="title"]');
    for (const el of headers) {
      textSources.push(el.textContent || "");
    }
    const suggestInput = document.querySelector(".c-search-box .c-text-field");
    if (suggestInput?.value) {
      textSources.push(suggestInput.value);
    }
    const combinedText = textSources.join(" ");
    for (const [companyId, keywords] of Object.entries(keywordMap)) {
      if (keywords.some((kw) => combinedText.includes(kw))) {
        console.log(`[Scout Assistant] Detected company: ${companyId} (keyword match in page text)`);
        return companyId;
      }
    }
    return null;
  }
  var init_company_detector = __esm({
    "src/content/company-detector.ts"() {
      "use strict";
      init_constants();
    }
  });

  // src/content/scout-quota-scraper.ts
  var scout_quota_scraper_exports = {};
  __export(scout_quota_scraper_exports, {
    initScoutQuotaScraper: () => initScoutQuotaScraper,
    refreshScoutQuota: () => refreshScoutQuota
  });
  function findRemaining() {
    const candidates = document.querySelectorAll(
      'header, .c-header, .c-page-header, .c-search-result__header, .c-page__main, [class*="scout"], [class*="remain"], [class*="header"]'
    );
    for (const el of candidates) {
      const text = el.innerText || el.textContent || "";
      const m2 = text.match(REMAINING_RE);
      if (m2) return parseInt(m2[1].replace(/,/g, ""), 10);
    }
    const bodyText = document.body?.innerText || document.body?.textContent || "";
    const m = bodyText.match(REMAINING_RE);
    return m ? parseInt(m[1].replace(/,/g, ""), 10) : null;
  }
  async function resolveCompanyId() {
    try {
      const detected = await detectCompanyFromPage();
      if (detected) return detected;
    } catch (err) {
      console.warn("[scout-quota] detectCompanyFromPage failed", err);
    }
    try {
      const stored = await storage.getCompany();
      if (stored) return stored;
    } catch (err) {
      console.warn("[scout-quota] storage.getCompany failed", err);
    }
    return null;
  }
  async function reportOnce() {
    if (inflight) return;
    const remaining = findRemaining();
    if (remaining == null || remaining < 0) return;
    if (remaining === lastReported) return;
    const companyId = await resolveCompanyId();
    if (!companyId) {
      console.log("[scout-quota] company not detected and storage empty, skipping");
      return;
    }
    inflight = true;
    try {
      await apiClient.postScoutQuotaSnapshot(companyId, remaining);
      lastReported = remaining;
      console.log(`[scout-quota] reported ${companyId} remaining=${remaining}`);
      try {
        await chrome.runtime.sendMessage({
          type: "QUOTA_SNAPSHOT_POSTED",
          companyId,
          remaining
        });
      } catch (err) {
        console.debug("[scout-quota] broadcast failed (no receiver?)", err);
      }
    } catch (err) {
      console.warn("[scout-quota] post failed", err);
    } finally {
      inflight = false;
    }
  }
  function watchForRemaining() {
    void reportOnce();
    const observer = new MutationObserver(() => {
      void reportOnce();
    });
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      setTimeout(() => observer.disconnect(), 5 * 60 * 1e3);
    }
  }
  function initScoutQuotaScraper() {
    setTimeout(() => watchForRemaining(), 1500);
    const onUrlChange = () => {
      lastReported = -1;
      setTimeout(() => watchForRemaining(), 800);
    };
    const origPush = history.pushState;
    history.pushState = function(...args) {
      const ret = origPush.apply(this, args);
      onUrlChange();
      return ret;
    };
    const origReplace = history.replaceState;
    history.replaceState = function(...args) {
      const ret = origReplace.apply(this, args);
      onUrlChange();
      return ret;
    };
    window.addEventListener("popstate", onUrlChange);
  }
  function refreshScoutQuota() {
    lastReported = -1;
    void reportOnce();
  }
  var REMAINING_RE, lastReported, inflight;
  var init_scout_quota_scraper = __esm({
    "src/content/scout-quota-scraper.ts"() {
      "use strict";
      init_api_client();
      init_storage();
      init_company_detector();
      REMAINING_RE = /今月のスカウト残数[\s\u00a0]*([0-9,]+)[\s\u00a0]*通/;
      lastReported = -1;
      inflight = false;
    }
  });

  // src/content/selectors.ts
  var SELECTORS = {
    /** 候補者カード */
    candidateCard: ".c-search-member-card",
    /** カード内の会員番号チェックボックス */
    memberCheckbox: 'input[name="member-select"]',
    /** カード内の「スカウトを送る」ボタン */
    scoutButton: "button.js-tour-guide-scout-button",
    /** サイドカバー（スカウト送信パネル） */
    overlay: ".c-side-cover",
    /** 閉じるボタン */
    closeButton: "a.c-side-cover__close-btn",
    /** タブ（プロフィール/職務経歴） */
    tab: "a.c-switcher__item",
    /** 本文テキストエリア */
    scoutTextarea: 'textarea[name="body"]',
    /** スカウト対象求人の隠しinput */
    jobOfferInput: 'input[name="jobOffer"]',
    /** スカウト対象求人のサジェスト入力欄 */
    jobOfferSuggestInput: ".c-search-box .c-text-field",
    /** プロフィールのDTラベル */
    definitionHead: "dt"
  };
  function getValueByLabel(root, label) {
    const dts = root.querySelectorAll(SELECTORS.definitionHead);
    for (const dt of dts) {
      if (dt.textContent?.trim() === label) {
        const dd = dt.nextElementSibling;
        if (dd && dd.tagName === "DD") {
          return dd.textContent?.trim() || "";
        }
      }
    }
    return "";
  }
  var FIELD_LABELS = {
    memberId: "\u4F1A\u54E1\u756A\u53F7",
    gender: "\u6027\u5225",
    age: "\u5E74\u9F62",
    area: "\u5C45\u4F4F\u5730",
    qualifications: "\u8CC7\u683C",
    experienceType: "\u7D4C\u9A13\u8077\u7A2E",
    employmentStatus: "\u5C31\u696D\u72B6\u6CC1",
    desiredJob: "\u5E0C\u671B\u8077\u7A2E",
    desiredArea: "\u5E0C\u671B\u52E4\u52D9\u5730",
    desiredEmploymentType: "\u5E0C\u671B\u52E4\u52D9\u5F62\u614B",
    desiredStart: "\u5E0C\u671B\u5165\u8077\u6642\u671F",
    selfPr: "\u81EA\u5DF1PR",
    specialConditions: "\u3053\u3060\u308F\u308A\u6761\u4EF6",
    favorite: "\u6C17\u306B\u306A\u308B"
  };
  function queryAllElements(root, selector) {
    return Array.from(root.querySelectorAll(selector));
  }

  // src/content/scraper.ts
  init_constants();

  // src/shared/utils.ts
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function randomSleep(min, max) {
    const ms = min + Math.floor(Math.random() * (max - min));
    return sleep(ms);
  }

  // src/content/scraper.ts
  function isOverlayVisible(el) {
    if (el.classList.contains("u-is-hidden")) return false;
    const html = el;
    const style = window.getComputedStyle(html);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (html.offsetWidth === 0 && html.offsetHeight === 0) return false;
    return true;
  }
  async function waitForContent(overlay) {
    const maxWait = 3e3;
    const interval = 20;
    let elapsed = 0;
    while (elapsed < maxWait) {
      if (overlay.querySelectorAll("dt").length > 0) return;
      await sleep(interval);
      elapsed += interval;
    }
  }
  async function waitForLabel(overlay, label, maxWait = 2500) {
    const interval = 50;
    let elapsed = 0;
    while (elapsed < maxWait) {
      const dts = overlay.querySelectorAll("dt");
      for (const dt of dts) {
        if (dt.textContent?.trim() === label) return;
      }
      await sleep(interval);
      elapsed += interval;
    }
  }
  async function waitForLabels(overlay, labels, minCount, maxWait = 3e3) {
    const interval = 50;
    let elapsed = 0;
    while (elapsed < maxWait) {
      const dts = overlay.querySelectorAll("dt");
      const foundLabels = /* @__PURE__ */ new Set();
      for (const dt of dts) {
        const text = dt.textContent?.trim() || "";
        if (labels.includes(text)) foundLabels.add(text);
      }
      if (foundLabels.size >= minCount) return;
      await sleep(interval);
      elapsed += interval;
    }
  }
  function waitForOverlay() {
    return new Promise((resolve, reject) => {
      const existing = document.querySelector(SELECTORS.overlay);
      if (existing && isOverlayVisible(existing)) {
        resolve(existing);
        return;
      }
      const timeout = setTimeout(() => {
        clearInterval(pollInterval);
        observer.disconnect();
        reject(new Error("\u30B5\u30A4\u30C9\u30AB\u30D0\u30FC\u8868\u793A\u304C\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u3057\u307E\u3057\u305F"));
      }, MUTATION_OBSERVER_TIMEOUT_MS);
      const pollInterval = setInterval(() => {
        const el = document.querySelector(SELECTORS.overlay);
        if (el && isOverlayVisible(el)) {
          clearTimeout(timeout);
          clearInterval(pollInterval);
          observer.disconnect();
          resolve(el);
        }
      }, 50);
      const observer = new MutationObserver(() => {
        const el = document.querySelector(SELECTORS.overlay);
        if (el && isOverlayVisible(el)) {
          clearTimeout(timeout);
          clearInterval(pollInterval);
          observer.disconnect();
          resolve(el);
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["style", "class"]
      });
    });
  }
  function waitForOverlayClose(timeoutMs = 5e3) {
    return new Promise((resolve) => {
      const startTime = Date.now();
      let sawOpen = false;
      const check = () => {
        const el = document.querySelector(SELECTORS.overlay);
        const hidden = !el || el.classList.contains("u-is-hidden") || el.offsetParent === null;
        if (!hidden) {
          sawOpen = true;
        }
        if (sawOpen && hidden) {
          resolve();
          return;
        }
        if (timeoutMs > 0 && Date.now() - startTime > timeoutMs) {
          resolve();
          return;
        }
        requestAnimationFrame(check);
      };
      check();
    });
  }
  function clickTab(overlay, tabText) {
    const tabs = overlay.querySelectorAll(SELECTORS.tab);
    for (const tab of tabs) {
      if (tab.textContent?.trim() === tabText) {
        tab.click();
        return;
      }
    }
  }
  function parseExperienceType(raw) {
    const match = raw.match(/^(.+?)(?:[（(](.+?)[）)])?$/);
    if (match) {
      return {
        type: match[1].trim(),
        years: match[2]?.trim() || ""
      };
    }
    return { type: raw, years: "" };
  }
  async function extractProfile(overlay) {
    await waitForContent(overlay);
    clickTab(overlay, "\u30D7\u30ED\u30D5\u30A3\u30FC\u30EB");
    await waitForLabels(
      overlay,
      [FIELD_LABELS.memberId, FIELD_LABELS.age, FIELD_LABELS.qualifications, FIELD_LABELS.selfPr],
      3,
      // 4つ中3つ出現すればOK
      3e3
    );
    await sleep(100);
    const expRaw = getValueByLabel(overlay, FIELD_LABELS.experienceType);
    const exp = parseExperienceType(expRaw);
    const profile = {
      member_id: getValueByLabel(overlay, FIELD_LABELS.memberId),
      gender: getValueByLabel(overlay, FIELD_LABELS.gender),
      age: getValueByLabel(overlay, FIELD_LABELS.age),
      area: getValueByLabel(overlay, FIELD_LABELS.area),
      qualifications: getValueByLabel(overlay, FIELD_LABELS.qualifications),
      experience_type: exp.type,
      experience_years: exp.years,
      employment_status: getValueByLabel(overlay, FIELD_LABELS.employmentStatus),
      desired_job: getValueByLabel(overlay, FIELD_LABELS.desiredJob),
      desired_area: getValueByLabel(overlay, FIELD_LABELS.desiredArea),
      desired_employment_type: getValueByLabel(overlay, FIELD_LABELS.desiredEmploymentType),
      desired_start: getValueByLabel(overlay, FIELD_LABELS.desiredStart),
      self_pr: getValueByLabel(overlay, FIELD_LABELS.selfPr),
      special_conditions: getValueByLabel(overlay, FIELD_LABELS.specialConditions),
      work_history_summary: "",
      scout_sent_date: "",
      is_favorite: (() => {
        const val = getValueByLabel(overlay, FIELD_LABELS.favorite);
        return val !== "" && val !== "\u672A\u5165\u529B";
      })()
    };
    clickTab(overlay, "\u8077\u52D9\u7D4C\u6B74");
    await waitForLabel(overlay, "\u52E4\u52D9\u5148\u540D", 2500).catch(() => {
    });
    await sleep(100);
    const profileLabels = new Set(Object.values(FIELD_LABELS));
    const allDts = overlay.querySelectorAll("dt");
    const workPairs = [];
    for (const dt of allDts) {
      const label = dt.textContent?.trim() || "";
      if (profileLabels.has(label)) continue;
      if (label.includes("\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8")) continue;
      const dd = dt.nextElementSibling;
      if (dd && dd.tagName === "DD") {
        const value = dd.textContent?.trim() || "";
        if (value) {
          workPairs.push(`${label}: ${value}`);
        }
      }
    }
    if (workPairs.length > 0) {
      profile.work_history_summary = workPairs.join("\n");
    }
    return profile;
  }
  function closeOverlay() {
    const btn = document.querySelector(SELECTORS.closeButton);
    if (btn) {
      btn.click();
    }
  }
  function getOverlayMemberId() {
    const overlay = document.querySelector(SELECTORS.overlay);
    if (!overlay || overlay.offsetParent === null) {
      return null;
    }
    const memberId = getValueByLabel(overlay, FIELD_LABELS.memberId);
    return memberId || null;
  }

  // src/content/message-selectors.ts
  var MESSAGE_SELECTORS = {
    /** メッセージビュー全体（data属性にthread_id等を持つ） */
    messageView: ".c-message-view.js-message-view",
    /** メッセージ一覧コンテナ */
    messageListInner: ".c-message-view__body-inner.js-message-view__body-inner",
    /** 個々のメッセージ要素 */
    messageItem: ".c-message",
    /** メッセージ内部（企業: --companion付き、求職者: なし） */
    messageInner: ".c-message__inner",
    /** 企業メッセージの識別クラス */
    companionModifier: "c-message__inner--companion",
    /** メッセージ本文 */
    messageBody: ".c-message__body",
    /** メッセージラベル（スカウト/応募/通常） */
    messageLabel: ".c-label",
    /** ヘッダー（sticky部分: 求人タイトル・候補者情報） */
    stickyHeader: ".c-message-view__sticky",
    /** 会員番号を含む要素（"03114222 | 53歳 女性"） */
    memberIdText: ".u-fs-lh-x-small-short.u-fw-bold.u-ml-15.u-color-grey-500",
    /** 候補者名 */
    candidateName: ".ds-o-flex .u-fs-lh-medium-short.u-fw-bold",
    /** 左サイドバー: 会話一覧 */
    conversationList: ".c-infinity-scroll__inner",
    /** 左サイドバー: 無限スクロールコンテナ */
    infinityScroll: ".c-infinity-scroll",
    /** 左サイドバー: ローダー（u-is-hidden時は読み込み完了） */
    infinityLoader: ".c-infinity-scroll .c-loader",
    /** 左サイドバー: 各会話リンク */
    conversationLink: "a.c-sub-side-nav__link",
    /** 左サイドバー: アクティブ会話 */
    conversationLinkActive: "a.c-sub-side-nav__link--active",
    /** 返信フォーム */
    replyForm: "form#message-send-form",
    /** 返信テキストエリア */
    replyTextarea: "form#message-send-form textarea"
  };

  // src/content/message-scraper.ts
  function extractConversation() {
    const view = document.querySelector(MESSAGE_SELECTORS.messageView);
    if (!view) {
      console.log("[Scout Assistant] \u30E1\u30C3\u30BB\u30FC\u30B8\u30D3\u30E5\u30FC\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      return null;
    }
    const memberId = extractMemberId();
    if (!memberId) {
      console.log("[Scout Assistant] \u4F1A\u54E1\u756A\u53F7\u3092\u53D6\u5F97\u3067\u304D\u307E\u305B\u3093");
      return null;
    }
    const messages = extractMessages();
    if (messages.length === 0) {
      console.log("[Scout Assistant] \u30E1\u30C3\u30BB\u30FC\u30B8\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      return null;
    }
    const headerInfo = extractHeaderInfo();
    const thread = {
      member_id: memberId,
      company: "",
      // サイドパネル側でstorageから補完
      started: messages[0].date,
      ...headerInfo,
      messages
    };
    return thread;
  }
  function extractMemberId() {
    const el = document.querySelector(MESSAGE_SELECTORS.memberIdText);
    if (!el) return null;
    const text = el.textContent?.trim() || "";
    const match = text.match(/^(\d+)/);
    return match ? match[1] : null;
  }
  function extractHeaderInfo() {
    const sticky = document.querySelector(MESSAGE_SELECTORS.stickyHeader);
    if (!sticky) return {};
    const nameEl = sticky.querySelector(MESSAGE_SELECTORS.candidateName);
    const candidate_name = nameEl?.textContent?.trim() || void 0;
    const idEl = sticky.querySelector(MESSAGE_SELECTORS.memberIdText);
    const idText = idEl?.textContent?.trim() || "";
    const ageGenderMatch = idText.match(/(\d+)歳\s*(男性|女性)/);
    const candidate_age = ageGenderMatch ? ageGenderMatch[1] + "\u6B73" : void 0;
    const candidate_gender = ageGenderMatch ? ageGenderMatch[2] : void 0;
    const titleEls = sticky.querySelectorAll(".u-fs-lh-medium-short.u-fw-bold");
    let job_title;
    for (const el of titleEls) {
      const text = el.textContent?.trim() || "";
      if (text.includes("\u6C42\u4EBA") || text.length > 20) {
        job_title = text;
        break;
      }
    }
    return { candidate_name, candidate_age, candidate_gender, job_title };
  }
  function extractMessages() {
    const container = document.querySelector(MESSAGE_SELECTORS.messageListInner);
    if (!container) return [];
    const messageEls = container.querySelectorAll(MESSAGE_SELECTORS.messageItem);
    const messages = [];
    const dateInfos = extractDateInfos(container);
    messageEls.forEach((el, index) => {
      const inner = el.querySelector(MESSAGE_SELECTORS.messageInner);
      if (!inner) return;
      const isCompany = inner.classList.contains(MESSAGE_SELECTORS.companionModifier);
      const role = isCompany ? "company" : "candidate";
      const bodyEl = el.querySelector(MESSAGE_SELECTORS.messageBody);
      if (!bodyEl) return;
      const text = extractMessageText(bodyEl);
      if (!text) return;
      const dateInfo = dateInfos[index];
      const date = dateInfo?.date || "";
      messages.push({ role, date, text });
    });
    return messages;
  }
  function extractMessageText(bodyEl) {
    const div = bodyEl.querySelector("div");
    if (!div) return bodyEl.textContent?.trim() || "";
    const spans = div.children;
    let textContent = "";
    for (let i = 0; i < spans.length; i++) {
      const span = spans[i];
      if (span.querySelector(MESSAGE_SELECTORS.messageLabel)) continue;
      textContent += span.textContent || "";
    }
    return textContent.trim();
  }
  function extractDateInfos(container) {
    const html = container.innerHTML;
    const regex = /(\d{4})\/(\d{2})\/(\d{2})\s+(\d{2}:\d{2})(\s+求職者)?/g;
    const infos = [];
    let match;
    while ((match = regex.exec(html)) !== null) {
      const dateStr = `${match[1]}-${match[2]}-${match[3]}`;
      const isCandidate = !!match[5];
      infos.push({ date: dateStr, isCandidate });
    }
    return infos;
  }
  function isMessagePage() {
    return location.pathname.includes("/messages");
  }
  async function waitForMessageView(timeoutMs = 5e3) {
    const start2 = Date.now();
    while (Date.now() - start2 < timeoutMs) {
      const view = document.querySelector(MESSAGE_SELECTORS.messageView);
      if (view) return true;
      await sleep(200);
    }
    return false;
  }
  var batchAborted = false;
  function abortBatchExtraction() {
    batchAborted = true;
  }
  async function loadAllConversations() {
    const scrollContainer = document.querySelector(MESSAGE_SELECTORS.infinityScroll);
    if (!scrollContainer) {
      console.log("[Scout Assistant] \u30B9\u30AF\u30ED\u30FC\u30EB\u30B3\u30F3\u30C6\u30CA\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093");
      return;
    }
    let prevCount = document.querySelectorAll(MESSAGE_SELECTORS.conversationLink).length;
    let stableRounds = 0;
    const maxStableRounds = 3;
    while (stableRounds < maxStableRounds) {
      scrollContainer.scrollTop = scrollContainer.scrollHeight;
      scrollContainer.dispatchEvent(new Event("scroll", { bubbles: true }));
      await sleep(1500);
      const currentCount = document.querySelectorAll(MESSAGE_SELECTORS.conversationLink).length;
      if (currentCount > prevCount) {
        prevCount = currentCount;
        stableRounds = 0;
      } else {
        stableRounds++;
      }
    }
    console.log(`[Scout Assistant] \u30B5\u30A4\u30C9\u30D0\u30FC\u8AAD\u307F\u8FBC\u307F\u5B8C\u4E86: ${document.querySelectorAll(MESSAGE_SELECTORS.conversationLink).length}\u4EF6`);
  }
  async function extractAllConversations(sendProgress) {
    batchAborted = false;
    await loadAllConversations();
    const links = document.querySelectorAll(MESSAGE_SELECTORS.conversationLink);
    const total = links.length;
    if (total === 0) {
      sendProgress({
        type: "CONVERSATION_ERROR",
        error: "\u4F1A\u8A71\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093"
      });
      return;
    }
    console.log(`[Scout Assistant] \u4E00\u62EC\u62BD\u51FA\u958B\u59CB: ${total}\u4EF6`);
    let extracted = 0;
    for (let i = 0; i < total; i++) {
      if (batchAborted) {
        console.log("[Scout Assistant] \u4E00\u62EC\u62BD\u51FA\u304C\u4E2D\u65AD\u3055\u308C\u307E\u3057\u305F");
        break;
      }
      const link = links[i];
      link.click();
      await sleep(500);
      const loaded = await waitForMessageView();
      if (!loaded) {
        console.log(`[Scout Assistant] ${i + 1}/${total}: \u30E1\u30C3\u30BB\u30FC\u30B8\u30D3\u30E5\u30FC\u8AAD\u307F\u8FBC\u307F\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8`);
        continue;
      }
      await sleep(300);
      const thread = extractConversation();
      if (thread) {
        extracted++;
        sendProgress({
          type: "CONVERSATION_PROGRESS",
          current: extracted,
          total,
          thread
        });
        console.log(`[Scout Assistant] ${i + 1}/${total}: ${thread.member_id} (${thread.messages.length}\u901A)`);
      } else {
        console.log(`[Scout Assistant] ${i + 1}/${total}: \u62BD\u51FA\u30B9\u30AD\u30C3\u30D7`);
      }
      if (i < total - 1) {
        await sleep(500);
      }
    }
    sendProgress({
      type: "CONVERSATION_BATCH_COMPLETE",
      count: extracted
    });
    console.log(`[Scout Assistant] \u4E00\u62EC\u62BD\u51FA\u5B8C\u4E86: ${extracted}/${total}\u4EF6`);
  }

  // src/content/form-filler.ts
  init_constants();
  function setNativeInputValue(el, value) {
    const prototype = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const nativeSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (nativeSetter) {
      nativeSetter.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function insertTextViaExecCommand(el, text) {
    el.focus();
    el.select();
    document.execCommand("insertText", false, text);
  }
  function clickOptionInMainWorld(index, jobId, jobName) {
    return new Promise((resolve) => {
      const timeout = setTimeout(() => {
        window.removeEventListener("__scout_job_offer_result__", handler);
        console.log("[Scout Assistant] Main world result timeout");
        resolve({ success: false, error: "main_world_timeout" });
      }, 3e3);
      const handler = (e) => {
        clearTimeout(timeout);
        window.removeEventListener("__scout_job_offer_result__", handler);
        const detail = e.detail;
        resolve({ success: detail.success, selectedValue: detail.selectedValue, error: detail.error });
      };
      window.addEventListener("__scout_job_offer_result__", handler);
      document.dispatchEvent(new CustomEvent("__scout_click_option", {
        detail: { selector: '[role="option"]', index, jobId, jobName }
      }));
    });
  }
  var companyMismatchChecked = false;
  var FALLBACK_CATEGORY_KEYWORDS = {
    nurse: ["\u770B\u8B77\u5E2B", "\u51C6\u770B\u8B77\u5E2B"],
    rehab_pt: ["\u7406\u5B66\u7642\u6CD5\u58EB"],
    pt: ["\u7406\u5B66\u7642\u6CD5\u58EB"],
    rehab_st: ["\u8A00\u8A9E\u8074\u899A\u58EB"],
    st: ["\u8A00\u8A9E\u8074\u899A\u58EB"],
    rehab_ot: ["\u4F5C\u696D\u7642\u6CD5\u58EB"],
    ot: ["\u4F5C\u696D\u7642\u6CD5\u58EB"],
    medical_office: ["\u533B\u7642\u4E8B\u52D9", "\u53D7\u4ED8"],
    dietitian: ["\u7BA1\u7406\u6804\u990A\u58EB", "\u6804\u990A\u58EB"],
    counselor: ["\u76F8\u8AC7\u652F\u63F4\u5C02\u9580\u54E1", "\u76F8\u8AC7\u652F\u63F4"],
    sales: ["\u5165\u5C45\u76F8\u8AC7\u54E1", "\u76F8\u8AC7\u54E1", "\u55B6\u696D"]
  };
  var EMPLOYMENT_KEYWORDS = {
    "\u30D1\u30FC\u30C8": ["\u30D1\u30FC\u30C8", "\u30D0\u30A4\u30C8"],
    "\u6B63\u793E\u54E1": ["\u6B63\u8077\u54E1", "\u6B63\u793E\u54E1"],
    "\u5951\u7D04": ["\u5951\u7D04\u793E\u54E1", "\u5951\u7D04\u8077\u54E1", "\u5951\u7D04"]
  };
  async function selectJobOffer(searchTerm, jobCategory, employmentType, categoryKeywords) {
    const suggestInput = document.querySelector(SELECTORS.jobOfferSuggestInput);
    if (!suggestInput) {
      return { success: false, error: "\u6C42\u4EBA\u691C\u7D22\u306E\u5165\u529B\u6B04\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
    }
    suggestInput.focus();
    suggestInput.select();
    document.execCommand("delete", false);
    await randomSleep(80, 200);
    console.log("[Scout Assistant] Searching job offers with:", searchTerm);
    insertTextViaExecCommand(suggestInput, searchTerm);
    await randomSleep(400, 700);
    const combobox = suggestInput.closest('[role="combobox"]');
    if (!combobox) {
      return { success: false, error: "combobox_not_found" };
    }
    let expanded = false;
    for (let i = 0; i < 80; i++) {
      if (combobox.getAttribute("aria-expanded") === "true") {
        expanded = true;
        break;
      }
      await sleep(100);
    }
    if (!expanded) {
      return { success: false, error: "dropdown_not_opened" };
    }
    let options = document.querySelectorAll('[role="option"]');
    for (let i = 0; i < 80 && options.length === 0; i++) {
      await sleep(100);
      options = document.querySelectorAll('[role="option"]');
    }
    if (options.length === 0) {
      return { success: false, error: "no_options" };
    }
    options.forEach((o, i) => console.log(`[Scout Assistant] option[${i}]:`, o.textContent?.trim().slice(0, 100)));
    if (!companyMismatchChecked) {
      companyMismatchChecked = true;
      try {
        const result = await chrome.storage.local.get([STORAGE_KEYS.COMPANY, STORAGE_KEYS.DETECTION_KEYWORDS]);
        const companyId = result[STORAGE_KEYS.COMPANY] || "";
        const storedKw = result[STORAGE_KEYS.DETECTION_KEYWORDS] || {};
        const keywords = storedKw[companyId] || COMPANY_FACILITY_KEYWORDS[companyId];
        if (keywords && keywords.length > 0) {
          const allText = Array.from(options).map((o) => o.textContent || "").join(" ");
          const found = keywords.some((kw) => allText.includes(kw));
          if (!found) {
            console.warn(`[Scout Assistant] COMPANY MISMATCH: selected=${companyId}, keywords=${keywords.join(",")}, not found in dropdown`);
            try {
              chrome.runtime.sendMessage({
                type: "COMPANY_MISMATCH",
                companyId,
                keywords
              });
            } catch {
            }
          }
        }
      } catch {
      }
    }
    const effectiveCategoryKeywords = categoryKeywords || FALLBACK_CATEGORY_KEYWORDS[jobCategory] || [];
    const empKeywords = EMPLOYMENT_KEYWORDS[employmentType] || [];
    let targetIndex = -1;
    for (let i = 0; i < options.length; i++) {
      const text = options[i].textContent?.trim() || "";
      const categoryMatch = effectiveCategoryKeywords.some((kw) => text.includes(kw));
      const empMatch = empKeywords.length === 0 || empKeywords.some((kw) => text.includes(kw));
      if (categoryMatch && empMatch) {
        targetIndex = i;
        break;
      }
    }
    if (targetIndex === -1) {
      for (let i = 0; i < options.length; i++) {
        const text = options[i].textContent?.trim() || "";
        if (effectiveCategoryKeywords.some((kw) => text.includes(kw))) {
          targetIndex = i;
          break;
        }
      }
    }
    if (targetIndex === -1 && options.length === 1) {
      targetIndex = 0;
    }
    if (targetIndex === -1) {
      console.log("[Scout Assistant] No matching option for:", jobCategory, employmentType);
      return { success: false, error: `no_match: ${jobCategory}/${employmentType}` };
    }
    const targetEl = options[targetIndex];
    console.log("[Scout Assistant] Matched option[%d]: %s", targetIndex, targetEl?.textContent?.trim().slice(0, 80));
    const mwResult = await clickOptionInMainWorld(targetIndex, "", "");
    if (!mwResult.success) {
      return { success: false, error: `main_world_failed: ${mwResult.error}` };
    }
    await sleep(300);
    const hiddenInput = document.querySelector(SELECTORS.jobOfferInput);
    if (!hiddenInput) {
      return { success: false, error: "hidden_input_not_found" };
    }
    if (!hiddenInput.value) {
      await sleep(500);
    }
    const selectedJobId = hiddenInput.value;
    if (selectedJobId) {
      console.log("[Scout Assistant] Job offer selected:", selectedJobId);
      return { success: true, selectedJobId };
    }
    return { success: false, error: "hidden_input_empty" };
  }
  async function fillScoutText(text) {
    const maxAttempts = 3;
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      const textarea2 = document.querySelector(SELECTORS.scoutTextarea);
      if (!textarea2) {
        if (attempt < maxAttempts - 1) {
          await sleep(300);
          continue;
        }
        return { success: false, error: "\u30B9\u30AB\u30A6\u30C8\u672C\u6587\u306E\u30C6\u30AD\u30B9\u30C8\u30A8\u30EA\u30A2\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
      }
      setNativeInputValue(textarea2, text);
      textarea2.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true }));
      textarea2.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true }));
      textarea2.focus();
      await sleep(200);
      const verify = document.querySelector(SELECTORS.scoutTextarea);
      if (verify && verify.value === text) {
        return { success: true };
      }
      console.log(`[Scout Assistant] fillScoutText: value not set on attempt ${attempt + 1}, retrying...`);
      await sleep(300);
    }
    const textarea = document.querySelector(SELECTORS.scoutTextarea);
    if (textarea) {
      console.log("[Scout Assistant] fillScoutText: using execCommand fallback");
      insertTextViaExecCommand(textarea, text);
      return { success: true };
    }
    return { success: false, error: "\u30C6\u30AD\u30B9\u30C8\u30A8\u30EA\u30A2\u3078\u306E\u5024\u30BB\u30C3\u30C8\u306B\u5931\u6557\u3057\u307E\u3057\u305F" };
  }

  // src/content/helpers.ts
  init_constants();
  function safeSendMessage(message) {
    chrome.runtime.sendMessage(message).catch(() => {
    });
  }
  function debugLog(step, status, detail) {
    safeSendMessage({
      type: "DEBUG_LOG",
      entry: { timestamp: localTimestamp(), step, status, detail }
    });
  }

  // src/content/fill-handler.ts
  function waitForFormElements(timeoutMs = 5e3) {
    return new Promise((resolve) => {
      const start2 = Date.now();
      const check = () => {
        const jobInput = document.querySelector(SELECTORS.jobOfferInput);
        const textarea = document.querySelector(SELECTORS.scoutTextarea);
        if (jobInput && textarea) {
          resolve();
          return;
        }
        if (Date.now() - start2 > timeoutMs) {
          resolve();
          return;
        }
        setTimeout(check, 100);
      };
      check();
    });
  }
  async function openOverlayForMember(memberId) {
    const cards = queryAllElements(document, SELECTORS.candidateCard);
    const normalizeId = (id) => id.replace(/^0+/, "");
    const targetId = normalizeId(memberId);
    let targetCard = null;
    for (const card of cards) {
      const checkbox = card.querySelector(SELECTORS.memberCheckbox);
      if (checkbox && normalizeId(checkbox.value) === targetId) {
        targetCard = card;
        break;
      }
    }
    if (!targetCard) {
      const foundIds = cards.map((c) => c.querySelector(SELECTORS.memberCheckbox)?.value).filter(Boolean);
      console.log("[Scout Assistant] Found member IDs:", foundIds.join(", "));
      return { success: false, error: `\u4F1A\u54E1\u756A\u53F7 ${memberId} \u306E\u30AB\u30FC\u30C9\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\uFF08${cards.length}\u4EF6\u4E2D\uFF09` };
    }
    const scoutBtn = targetCard.querySelector(SELECTORS.scoutButton);
    if (!scoutBtn) {
      console.log("[Scout Assistant] Card found but no scout button. Card HTML:", targetCard.innerHTML.slice(0, 200));
      return { success: false, error: "\u30B9\u30AB\u30A6\u30C8\u30DC\u30BF\u30F3\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
    }
    scoutBtn.click();
    try {
      await waitForOverlay();
      await waitForFormElements();
      return { success: true };
    } catch {
      return { success: false, error: "\u30B9\u30AB\u30A6\u30C8\u753B\u9762\u306E\u8868\u793A\u304C\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8\u3057\u307E\u3057\u305F" };
    }
  }
  async function trySelectJobOffer(searchTerm, jobCategory, employmentType, memberId, categoryKeywords) {
    debugLog("\u6C42\u4EBA\u9078\u629E", "pending");
    const jobResult = await selectJobOffer(searchTerm, jobCategory, employmentType, categoryKeywords);
    debugLog("\u6C42\u4EBA\u9078\u629E", jobResult.success ? "success" : "error", jobResult.success ? `${jobCategory}/${employmentType}` : jobResult.error);
    if (!jobResult.success) {
      debugLog("\u6C42\u4EBA\u9078\u629E\u5931\u6557", "error", `\u624B\u52D5\u3067\u6C42\u4EBA\u3092\u9078\u629E\u3057\u3066\u304F\u3060\u3055\u3044: ${jobResult.error}`);
      safeSendMessage({ type: "JOB_OFFER_FAILED", memberId, error: jobResult.error || "\u6C42\u4EBA\u81EA\u52D5\u9078\u629E\u306B\u5931\u6557" });
    }
    return jobResult;
  }
  async function handleFillJobOffer(searchTerm, jobCategory, employmentType, memberId) {
    const existingOverlay = document.querySelector(SELECTORS.overlay);
    if (existingOverlay && !existingOverlay.classList.contains("u-is-hidden")) {
      await waitForFormElements();
      return trySelectJobOffer(searchTerm, jobCategory, employmentType, memberId);
    }
    if (memberId) {
      const openResult = await openOverlayForMember(memberId);
      if (!openResult.success) return openResult;
      return trySelectJobOffer(searchTerm, jobCategory, employmentType, memberId);
    }
    return { success: false, error: "\u30B9\u30AB\u30A6\u30C8\u753B\u9762\u304C\u958B\u3044\u3066\u3044\u307E\u305B\u3093" };
  }
  async function handleFillForm(text, memberId, searchTerm, jobCategory, employmentType, skipJobOffer, categoryKeywords) {
    const existingOverlay = document.querySelector(SELECTORS.overlay);
    if (existingOverlay && !existingOverlay.classList.contains("u-is-hidden")) {
      let jobOfferFailed = false;
      if (searchTerm && jobCategory && employmentType && !skipJobOffer) {
        const jobResult = await trySelectJobOffer(searchTerm, jobCategory, employmentType, memberId, categoryKeywords);
        jobOfferFailed = !jobResult.success;
        await randomSleep(250, 600);
      }
      debugLog("\u672C\u6587\u30BB\u30C3\u30C8", "pending");
      const result = await fillScoutText(text);
      debugLog("\u672C\u6587\u30BB\u30C3\u30C8", result.success ? "success" : "error", result.success ? `${text.length}\u6587\u5B57` : result.error);
      return { ...result, jobOfferFailed };
    }
    if (memberId) {
      debugLog("\u30AB\u30FC\u30C9\u691C\u7D22", "pending", memberId);
      console.log(`[Scout Assistant] Looking for member ${memberId}`);
      const openResult = await openOverlayForMember(memberId);
      if (!openResult.success) {
        debugLog("\u30AB\u30FC\u30C9\u691C\u7D22", "error", openResult.error);
        return openResult;
      }
      debugLog("\u30AB\u30FC\u30C9\u691C\u7D22", "success", "\u30AB\u30FC\u30C9\u767A\u898B");
      let jobOfferFailed = false;
      if (searchTerm && jobCategory && employmentType && !skipJobOffer) {
        const jobResult = await trySelectJobOffer(searchTerm, jobCategory, employmentType, memberId, categoryKeywords);
        jobOfferFailed = !jobResult.success;
        await randomSleep(250, 600);
      }
      debugLog("\u672C\u6587\u30BB\u30C3\u30C8", "pending");
      const result = await fillScoutText(text);
      debugLog("\u672C\u6587\u30BB\u30C3\u30C8", result.success ? "success" : "error", result.success ? `${text.length}\u6587\u5B57` : result.error);
      return { ...result, jobOfferFailed };
    }
    return { success: false, error: "\u30B9\u30AB\u30A6\u30C8\u753B\u9762\u304C\u958B\u3044\u3066\u3044\u307E\u305B\u3093\u3002\u5148\u306B\u5019\u88DC\u8005\u306E\u30B9\u30AB\u30A6\u30C8\u753B\u9762\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002" };
  }

  // src/content/overlay-observer.ts
  function setupOverlayObserver() {
    let lastMemberId = null;
    const observer = new MutationObserver(() => {
      const memberId = getOverlayMemberId();
      if (memberId && memberId !== lastMemberId) {
        lastMemberId = memberId;
        safeSendMessage({
          type: "OVERLAY_MEMBER_ID",
          memberId
        });
      } else if (!memberId && lastMemberId) {
        lastMemberId = null;
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["style", "class"]
    });
  }

  // src/content/extraction.ts
  init_constants();
  var aborted = false;
  function abort() {
    aborted = true;
  }
  function detectFavorite(card) {
    const text = card.textContent || "";
    return text.includes("\u300C\u6C17\u306B\u306A\u308B\u300D\u3057\u305F\u6C42\u8077\u8005");
  }
  function extractScoutSentDate(card) {
    const allText = card.querySelectorAll("*");
    for (const el of allText) {
      const text = el.textContent?.trim() || "";
      if (text.startsWith("\u30B9\u30AB\u30A6\u30C8\u9001\u4FE1\u65E5")) {
        const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
        if (lines.length >= 2) {
          return lines.slice(1).join(", ");
        }
        const next = el.nextElementSibling;
        if (next) {
          return next.textContent?.trim() || "";
        }
        return text.replace("\u30B9\u30AB\u30A6\u30C8\u9001\u4FE1\u65E5", "").trim();
      }
    }
    return "";
  }
  async function startExtraction(count, startMemberId) {
    aborted = false;
    const cards = queryAllElements(document, SELECTORS.candidateCard);
    let startIndex = 0;
    if (startMemberId) {
      const idx = cards.findIndex((card) => {
        const checkbox = card.querySelector(SELECTORS.memberCheckbox);
        return checkbox?.value === startMemberId;
      });
      if (idx === -1) {
        safeSendMessage({ type: "EXTRACTION_ERROR", error: `\u4F1A\u54E1\u756A\u53F7 ${startMemberId} \u304C\u30EA\u30B9\u30C8\u306B\u898B\u3064\u304B\u308A\u307E\u305B\u3093` });
        return;
      }
      startIndex = idx;
    }
    const available = cards.length - startIndex;
    const total = Math.min(count, available);
    console.log(`[Scout Assistant] Found ${cards.length} cards, startIndex=${startIndex}, will extract ${total}`);
    const profiles = [];
    for (let i = 0; i < total; i++) {
      const cardIndex = startIndex + i;
      if (aborted) break;
      const scoutSentDate = extractScoutSentDate(cards[cardIndex]);
      const isFavorite = detectFavorite(cards[cardIndex]);
      const scoutBtn = cards[cardIndex].querySelector(SELECTORS.scoutButton);
      console.log(`[Scout Assistant] Card ${cardIndex}: scoutBtn =`, scoutBtn ? "found" : "NOT FOUND", "selector:", SELECTORS.scoutButton);
      if (!scoutBtn) continue;
      scoutBtn.click();
      console.log(`[Scout Assistant] Card ${cardIndex}: clicked scout button, waiting for overlay...`);
      const overlay = await waitForOverlay();
      console.log(`[Scout Assistant] Card ${cardIndex}: overlay appeared`);
      const profile = await extractProfile(overlay);
      profile.scout_sent_date = scoutSentDate;
      profile.is_favorite = isFavorite || profile.is_favorite;
      profiles.push(profile);
      safeSendMessage({
        type: "EXTRACTION_PROGRESS",
        current: i + 1,
        total,
        profile
      });
      closeOverlay();
      await waitForOverlayClose();
      if (i < total - 1) {
        await randomSleep(EXTRACTION_INTERVAL_MS, EXTRACTION_INTERVAL_MS * 4);
      }
    }
    safeSendMessage({
      type: "EXTRACTION_COMPLETE",
      profiles
    });
  }

  // src/content/continuous-sender.ts
  init_constants();
  var jobOfferResumeResolver = null;
  function resumeAfterJobOfferFix() {
    if (jobOfferResumeResolver) {
      jobOfferResumeResolver();
      jobOfferResumeResolver = null;
    }
  }
  var active = false;
  var skipResolver = null;
  var sendCompleteResolver = null;
  var stopModalDismisser = false;
  var confirmCancelResolver = null;
  function isActive() {
    return active;
  }
  function stop() {
    active = false;
    if (skipResolver) {
      skipResolver();
      skipResolver = null;
    }
    if (confirmCancelResolver) {
      confirmCancelResolver();
      confirmCancelResolver = null;
    }
  }
  function skipCurrent() {
    if (skipResolver) {
      skipResolver();
      skipResolver = null;
    }
  }
  function injectDryRunBanner() {
    const overlay = document.querySelector(".c-side-cover");
    if (!overlay) return;
    const banner = document.createElement("div");
    banner.id = "dry-run-banner";
    banner.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:999999;background:#ef4444;color:white;text-align:center;padding:8px;font-weight:bold;font-size:14px;";
    banner.textContent = "\u30C6\u30B9\u30C8\u30E2\u30FC\u30C9 - \u9001\u4FE1\u3057\u306A\u3044\u3067\u304F\u3060\u3055\u3044";
    overlay.prepend(banner);
  }
  function removeDryRunBanner() {
    document.getElementById("dry-run-banner")?.remove();
  }
  async function pollAndDismissPostSendModal() {
    stopModalDismisser = false;
    const maxPollingMs = 5 * 60 * 1e3;
    const started = Date.now();
    while (!stopModalDismisser && Date.now() - started < maxPollingMs) {
      const modals = document.querySelectorAll(".c-modal.js-modal");
      for (const modal of modals) {
        if (modal.classList.contains("u-is-hidden")) continue;
        const body = modal.textContent || "";
        if (body.includes("\u30B9\u30AB\u30A6\u30C8\u3092\u9001\u4FE1\u3057\u307E\u3057\u305F")) {
          const okBtn = modal.querySelector("button");
          if (okBtn) {
            console.log("[Scout Assistant] Dismissing post-send modal (polling)");
            okBtn.click();
            await sleep(500);
            console.log("[Scout Assistant] Closing overlay after modal dismiss");
            closeOverlay();
            await sleep(500);
            if (sendCompleteResolver) {
              console.log("[Scout Assistant] Resolving send complete");
              sendCompleteResolver("closed");
            }
            return;
          }
        }
      }
      await sleep(200);
    }
  }
  function waitForOverlayCloseOrSkip(timeoutMs) {
    return new Promise((resolve) => {
      let resolved = false;
      const doResolve = (action) => {
        if (resolved) return;
        resolved = true;
        skipResolver = null;
        sendCompleteResolver = null;
        resolve(action);
      };
      skipResolver = () => {
        closeOverlay();
        doResolve("skipped");
      };
      sendCompleteResolver = doResolve;
      waitForOverlayClose(timeoutMs).then(() => {
        doResolve("closed");
      });
    });
  }
  function getNextCandidate() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_NEXT_CANDIDATE" }, (response) => {
        if (response?.type === "NEXT_CANDIDATE") {
          resolve(response.candidate || null);
        } else {
          resolve(null);
        }
      });
    });
  }
  function requestConfirmation(data) {
    return new Promise((resolve) => {
      let resolved = false;
      const cleanup = () => {
        if (resolved) return;
        resolved = true;
        chrome.runtime.onMessage.removeListener(listener);
        confirmCancelResolver = null;
      };
      const listener = (msg) => {
        if (msg.type === "CONFIRM_RESPONSE") {
          cleanup();
          resolve(msg.result);
        }
      };
      chrome.runtime.onMessage.addListener(listener);
      confirmCancelResolver = () => {
        cleanup();
        resolve("cancelled");
      };
      safeSendMessage({
        type: "CONFIRM_BEFORE_SEND",
        data: {
          member_id: data.memberId,
          label: data.templateType,
          template_type: data.templateType,
          personalized_text: data.personalizedText,
          full_scout_text: data.fullScoutText,
          jobOfferName: data.jobOfferLabel
        }
      });
    });
  }
  async function start() {
    active = true;
    console.log("[Scout Assistant] Continuous send started");
    const dryRunResult = await chrome.storage.local.get(STORAGE_KEYS.DRY_RUN_MODE);
    const dryRun = !!dryRunResult[STORAGE_KEYS.DRY_RUN_MODE];
    if (dryRun) {
      debugLog("\u30E2\u30FC\u30C9", "success", "\u30C9\u30E9\u30A4\u30E9\u30F3\u30E2\u30FC\u30C9\u6709\u52B9");
    }
    while (active) {
      const next = await getNextCandidate();
      if (!next) {
        console.log("[Scout Assistant] No more candidates, stopping continuous send");
        break;
      }
      console.log(`[Scout Assistant] Processing candidate: ${next.memberId}`);
      const { searchTerm, jobCategory, employmentType, categoryKeywords } = next;
      const autoJobOfferResult = await chrome.storage.local.get(STORAGE_KEYS.AUTO_JOB_OFFER);
      const skipJobOffer = autoJobOfferResult[STORAGE_KEYS.AUTO_JOB_OFFER] === false;
      console.log(`[Scout Assistant] Calling handleFillForm for ${next.memberId}, jobCategory:`, jobCategory, employmentType, "skipJobOffer:", skipJobOffer);
      const result = await handleFillForm(next.text, next.memberId, searchTerm, jobCategory, employmentType, skipJobOffer, categoryKeywords);
      console.log(`[Scout Assistant] handleFillForm result:`, result);
      if (!result.success) {
        console.error("[Scout Assistant] Fill form failed:", result.error);
        safeSendMessage({ type: "CANDIDATE_SENT", memberId: next.memberId });
        await randomSleep(200, 600);
        continue;
      }
      if (result.jobOfferFailed) {
        debugLog("\u4E00\u6642\u505C\u6B62", "error", "\u6C42\u4EBA\u3092\u624B\u52D5\u3067\u9078\u629E\u3057\u3066\u304B\u3089\u300C\u518D\u958B\u300D\u3092\u62BC\u3057\u3066\u304F\u3060\u3055\u3044");
        console.log("[Scout Assistant] Job offer selection failed, pausing for manual selection");
        await new Promise((resolve) => {
          jobOfferResumeResolver = resolve;
          const origSkipResolver = skipResolver;
          skipResolver = () => {
            jobOfferResumeResolver = null;
            if (origSkipResolver) origSkipResolver();
            resolve();
          };
        });
        if (!active) break;
        debugLog("\u518D\u958B", "success", "\u624B\u52D5\u9078\u629E\u78BA\u8A8D\u5F8C\u306B\u7D9A\u884C");
      }
      if (dryRun) {
        injectDryRunBanner();
        debugLog("\u30C9\u30E9\u30A4\u30E9\u30F3", "success", "2\u79D2\u5F8C\u306B\u81EA\u52D5\u30AF\u30ED\u30FC\u30BA");
        await randomSleep(1500, 2500);
        removeDryRunBanner();
        closeOverlay();
        await waitForOverlayClose();
        safeSendMessage({ type: "DRY_RUN_COMPLETE", memberId: next.memberId });
        await randomSleep(200, 600);
        continue;
      }
      console.log(`[Scout Assistant] Showing confirmation popup for ${next.memberId}`);
      debugLog("\u78BA\u8A8D\u30DD\u30C3\u30D7\u30A2\u30C3\u30D7", "pending", "\u78BA\u8A8D\u4E2D...");
      const confirmResult = await requestConfirmation({
        memberId: next.memberId,
        text: next.text,
        jobOfferLabel: jobCategory ? `${jobCategory}/${employmentType || ""}` : "",
        templateType: "",
        personalizedText: "",
        fullScoutText: next.text
      });
      console.log(`[Scout Assistant] Confirmation result: ${confirmResult}`);
      if (confirmResult === "cancelled") {
        debugLog("\u78BA\u8A8D\u30DD\u30C3\u30D7\u30A2\u30C3\u30D7", "success", "\u505C\u6B62");
        closeOverlay();
        await waitForOverlayClose();
        break;
      }
      if (confirmResult === "ng") {
        debugLog("\u78BA\u8A8D\u30DD\u30C3\u30D7\u30A2\u30C3\u30D7", "success", "\u30B9\u30AD\u30C3\u30D7");
        closeOverlay();
        await waitForOverlayClose();
        safeSendMessage({ type: "CANDIDATE_SENT", memberId: next.memberId });
        await randomSleep(300, 800);
        continue;
      }
      debugLog("\u78BA\u8A8D\u30DD\u30C3\u30D7\u30A2\u30C3\u30D7", "success", "OK \u2192 \u9001\u4FE1\u5F85\u3061");
      console.log(`[Scout Assistant] Waiting for overlay close or skip...`);
      debugLog("\u78BA\u8A8D\u5F85\u3061", "pending", "\u9001\u4FE1 or \u30B9\u30AD\u30C3\u30D7\u3092\u5F85\u6A5F\u4E2D");
      const modalDismisser = pollAndDismissPostSendModal();
      const action = await waitForOverlayCloseOrSkip(0);
      stopModalDismisser = true;
      console.log(`[Scout Assistant] Overlay action: ${action}, active: ${active}`);
      debugLog("\u78BA\u8A8D\u5F85\u3061", "success", action === "skipped" ? "\u30B9\u30AD\u30C3\u30D7" : "\u9001\u4FE1\u5B8C\u4E86");
      if (!active) {
        console.log("[Scout Assistant] active is false, breaking");
        break;
      }
      await randomSleep(400, 1200);
      safeSendMessage({ type: "CANDIDATE_SENT", memberId: next.memberId });
    }
    active = false;
    skipResolver = null;
    console.log("[Scout Assistant] Continuous send ended");
    safeSendMessage({ type: "CONTINUOUS_SEND_COMPLETE" });
    try {
      const { refreshScoutQuota: refreshScoutQuota2 } = await Promise.resolve().then(() => (init_scout_quota_scraper(), scout_quota_scraper_exports));
      setTimeout(() => refreshScoutQuota2(), 2e3);
    } catch (err) {
      console.warn("[scout-quota] refresh after continuous send failed", err);
    }
  }

  // src/content/job-offer-extractor.ts
  async function extractJobOffers() {
    const suggestInput = document.querySelector(SELECTORS.jobOfferSuggestInput);
    if (!suggestInput) {
      return { success: false, offers: [], error: "\u6C42\u4EBA\u691C\u7D22\u306E\u5165\u529B\u6B04\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3002\u30B9\u30AB\u30A6\u30C8\u9001\u4FE1\u30D1\u30CD\u30EB\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002" };
    }
    suggestInput.focus();
    suggestInput.select();
    document.execCommand("delete", false);
    await sleep(200);
    suggestInput.dispatchEvent(new Event("input", { bubbles: true }));
    suggestInput.dispatchEvent(new Event("change", { bubbles: true }));
    await sleep(500);
    const combobox = suggestInput.closest('[role="combobox"]');
    if (!combobox) {
      return { success: false, offers: [], error: "combobox\u8981\u7D20\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093" };
    }
    let expanded = false;
    for (let i = 0; i < 50; i++) {
      if (combobox.getAttribute("aria-expanded") === "true") {
        expanded = true;
        break;
      }
      await sleep(100);
    }
    if (!expanded) {
      suggestInput.click();
      await sleep(500);
      expanded = combobox.getAttribute("aria-expanded") === "true";
    }
    if (!expanded) {
      return { success: false, offers: [], error: "\u30C9\u30ED\u30C3\u30D7\u30C0\u30A6\u30F3\u304C\u958B\u304D\u307E\u305B\u3093\u3067\u3057\u305F" };
    }
    let options = document.querySelectorAll('[role="option"]');
    for (let i = 0; i < 50 && options.length === 0; i++) {
      await sleep(100);
      options = document.querySelectorAll('[role="option"]');
    }
    if (options.length === 0) {
      return { success: false, offers: [], error: "\u6C42\u4EBA\u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3067\u3057\u305F" };
    }
    const offers = [];
    for (const option of options) {
      const text = option.textContent?.trim() || "";
      if (!text) continue;
      const match = text.match(/^(\d+)\s+(.+)$/);
      if (match) {
        offers.push({ id: match[1], name: match[2] });
      } else {
        offers.push({ id: "", name: text });
      }
    }
    suggestInput.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    console.log(`[Scout Assistant] Extracted ${offers.length} job offers`);
    return { success: true, offers };
  }

  // src/content/facility-scraper.ts
  var aborted2 = false;
  function abortFacilityExtraction() {
    aborted2 = true;
  }
  function extractFacilityList() {
    const facilities = [];
    const navLinks = document.querySelectorAll("a.c-sub-side-nav__link");
    console.log(`[FacilityScraper] Found ${navLinks.length} sidebar nav links`);
    const excludeTexts = ["\u3059\u3079\u3066\u306E\u65BD\u8A2D", "\u65B0\u898F\u767B\u9332", "\u6C42\u4EBA\u3092\u65B0\u898F", "\u65BD\u8A2D\u3092\u65B0\u898F"];
    for (const link of navLinks) {
      const name = link.textContent?.trim() || "";
      if (!name) continue;
      if (excludeTexts.some((t) => name.includes(t))) continue;
      if (name.startsWith("\uFF0B") || name.startsWith("+")) continue;
      const href = link.href || "";
      const match = href.match(/facility_id=(\d+)/);
      let facilityId = match?.[1] || "";
      if (!facilityId) {
        const numMatch = href.match(/facilities\/(\d+)/) || href.match(/\/(\d+)/);
        if (numMatch) facilityId = numMatch[1];
      }
      if (!facilityId) {
        console.log(`[FacilityScraper] Nav link without ID: "${name}" href="${href}"`);
        facilityId = `__index_${Array.from(navLinks).indexOf(link)}`;
      }
      facilities.push({ facilityId, name });
      console.log(`[FacilityScraper] Found facility: "${name}" (${facilityId})`);
    }
    if (facilities.length === 0) {
      console.log("[FacilityScraper] Fallback: searching all links with facility_id");
      const allLinks = document.querySelectorAll("a");
      for (const link of allLinks) {
        const href = link.href || "";
        const match = href.match(/facility_id=(\d+)/);
        if (match) {
          const name = link.textContent?.trim() || "";
          if (!name) continue;
          if (excludeTexts.some((t) => name.includes(t))) continue;
          if (name.startsWith("\uFF0B") || name.startsWith("+")) continue;
          facilities.push({ facilityId: match[1], name });
        }
      }
    }
    const seen = /* @__PURE__ */ new Set();
    return facilities.filter((f) => {
      if (seen.has(f.facilityId)) return false;
      seen.add(f.facilityId);
      return true;
    });
  }
  function extractJobFieldsFromText(rawText) {
    const fields = {};
    const recruitIdx = rawText.indexOf("\u52DF\u96C6\u5185\u5BB9");
    if (recruitIdx === -1) return fields;
    const text = rawText.substring(recruitIdx);
    const labels = [
      "\u52DF\u96C6\u8077\u7A2E",
      "\u4ED5\u4E8B\u5185\u5BB9",
      "\u8A3A\u7642\u79D1\u76EE\u30FB\u30B5\u30FC\u30D3\u30B9\u5F62\u614B",
      "\u7D66\u4E0E",
      "\u7D66\u4E0E\u306E\u5099\u8003",
      "\u5F85\u9047",
      "\u6559\u80B2\u4F53\u5236\u30FB\u7814\u4FEE",
      "\u52E4\u52D9\u6642\u9593",
      "\u4F11\u65E5",
      "\u5FDC\u52DF\u8981\u4EF6",
      "\u6B53\u8FCE\u8981\u4EF6",
      "\u6CD5\u4EBA\u30FB\u65BD\u8A2D\u540D",
      "\u52DF\u96C6\u8077\u7A2E",
      "\u30A2\u30AF\u30BB\u30B9"
    ];
    const positions = [];
    for (const label of labels) {
      let searchFrom = 0;
      while (true) {
        const idx = text.indexOf(label, searchFrom);
        if (idx === -1) break;
        positions.push({ label, start: idx, end: idx + label.length });
        searchFrom = idx + label.length;
        if (label !== "\u52DF\u96C6\u8077\u7A2E") break;
      }
    }
    positions.sort((a, b) => a.start - b.start);
    for (let i = 0; i < positions.length; i++) {
      const { label, end } = positions[i];
      const nextStart = i + 1 < positions.length ? positions[i + 1].start : text.length;
      const content = text.substring(end, nextStart).trim();
      if (content && !fields[label]) {
        let cleaned = content;
        if (cleaned.startsWith(label)) {
          cleaned = cleaned.substring(label.length).trim();
        }
        if (cleaned) {
          fields[label] = cleaned;
        }
      }
    }
    return fields;
  }
  function applyJobSections(job, fields) {
    const mapping = [
      ["jobType", ["\u52DF\u96C6\u8077\u7A2E"]],
      ["jobDescription", ["\u4ED5\u4E8B\u5185\u5BB9"]],
      ["salary", ["\u7D66\u4E0E"]],
      ["benefits", ["\u5F85\u9047"]],
      ["workingHours", ["\u52E4\u52D9\u6642\u9593"]],
      ["holidays", ["\u4F11\u65E5"]]
    ];
    for (const [field, labels] of mapping) {
      for (const label of labels) {
        if (fields[label]) {
          job[field] = fields[label];
          break;
        }
      }
    }
    if (fields["\u7D66\u4E0E\u306E\u5099\u8003"]) {
      job.salary = (job.salary ? job.salary + "\n\n" : "") + fields["\u7D66\u4E0E\u306E\u5099\u8003"];
    }
    if (fields["\u6559\u80B2\u4F53\u5236\u30FB\u7814\u4FEE"]) {
      job.benefits = (job.benefits ? job.benefits + "\n\n\u3010\u7814\u4FEE\u3011" : "") + fields["\u6559\u80B2\u4F53\u5236\u30FB\u7814\u4FEE"];
    }
    const reqKey = Object.keys(fields).find((k) => k.includes("\u5FDC\u52DF\u8981\u4EF6") || k.includes("\u5FDC\u52DF\u8CC7\u683C"));
    if (reqKey) {
      job.jobDescription = (job.jobDescription ? job.jobDescription + "\n\n\u3010\u5FDC\u52DF\u8981\u4EF6\u3011" : "") + fields[reqKey];
    }
    const serviceKey = Object.keys(fields).find((k) => k.includes("\u8A3A\u7642\u79D1\u76EE") || k.includes("\u30B5\u30FC\u30D3\u30B9\u5F62\u614B"));
    if (serviceKey) {
      job.jobDescription = (job.jobDescription ? job.jobDescription + "\n\n\u3010\u30B5\u30FC\u30D3\u30B9\u5F62\u614B\u3011" : "") + fields[serviceKey];
    }
  }
  async function fetchPreviewPage(url) {
    console.log("[FacilityScraper] Fetching preview:", url);
    const job = {
      title: "",
      jobType: "",
      jobDescription: "",
      salary: "",
      benefits: "",
      workingHours: "",
      holidays: "",
      rawText: ""
    };
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status}: ${url}`);
    }
    const html = await res.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    job.rawText = doc.body?.textContent?.trim() || "";
    const titleEl = doc.querySelector("h1, h2, .title");
    if (titleEl) {
      job.title = titleEl.textContent?.trim() || "";
    }
    const fields = extractJobFieldsFromText(job.rawText);
    applyJobSections(job, fields);
    console.log("[FacilityScraper] Preview fetched:", job.title || "(no title)", "fields:", Object.keys(fields).join(", "));
    return job;
  }
  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function waitForDomUpdate(check, timeoutMs = 5e3) {
    return new Promise((resolve) => {
      if (check()) {
        resolve(true);
        return;
      }
      const observer = new MutationObserver(() => {
        if (check()) {
          observer.disconnect();
          resolve(true);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      setTimeout(() => {
        observer.disconnect();
        resolve(check());
      }, timeoutMs);
    });
  }
  async function navigateToFacility(facilityId) {
    if (facilityId.startsWith("__index_")) {
      const index = parseInt(facilityId.replace("__index_", ""), 10);
      const navLinks = document.querySelectorAll("a.c-sub-side-nav__link");
      const link = navLinks[index];
      if (link) {
        console.log(`[FacilityScraper] Clicking sidebar link by index ${index}: "${link.textContent?.trim()}"`);
        link.click();
        await wait(1e3);
        await waitForDomUpdate(() => !!document.querySelector(".c-sub-side-nav__link--active"), 5e3);
        await wait(500);
        return true;
      }
      return false;
    }
    const links = document.querySelectorAll("a");
    for (const link of links) {
      const href = link.href || "";
      const linkText = link.textContent?.trim() || "";
      if (href.includes(`facility_id=${facilityId}`) && !linkText.startsWith("\uFF0B") && !linkText.startsWith("+") && !linkText.includes("\u65B0\u898F\u767B\u9332")) {
        console.log(`[FacilityScraper] Clicking sidebar link for facility ${facilityId}: "${linkText}"`);
        link.click();
        await wait(500);
        const updated = await waitForDomUpdate(() => {
          const text = document.body.textContent || "";
          return text.includes(`\u65BD\u8A2DID`) && text.includes(facilityId);
        }, 5e3);
        if (!updated) {
          console.warn(`[FacilityScraper] DOM update timeout for facility ${facilityId}`);
        }
        await wait(500);
        return true;
      }
    }
    console.warn(`[FacilityScraper] Sidebar link not found for facility ${facilityId}`);
    return false;
  }
  function collectActiveJobIdsFromDom() {
    const jobIds = [];
    const pageText = document.body.textContent || "";
    const allIds = [];
    const idRegex = /求人ID[:：]\s*(\d+)/g;
    let match;
    while ((match = idRegex.exec(pageText)) !== null) {
      allIds.push({ id: match[1], position: match.index });
    }
    console.log(`[FacilityScraper] Found ${allIds.length} job IDs in DOM`);
    for (const { id, position } of allIds) {
      const contextStart = Math.max(0, position - 500);
      const contextEnd = Math.min(pageText.length, position + 500);
      const context = pageText.substring(contextStart, contextEnd);
      if (context.includes("\u63B2\u8F09\u4E2D")) {
        jobIds.push(id);
        console.log(`[FacilityScraper] Job ${id}: \u63B2\u8F09\u4E2D`);
      } else {
        console.log(`[FacilityScraper] Job ${id}: not active (skipped)`);
      }
    }
    return [...new Set(jobIds)];
  }
  function extractFacilityBasicInfo(facilityId) {
    const pageText = document.body.textContent || "";
    let facilityName = "";
    const idMatch = pageText.match(new RegExp(`([^\\n]{1,50})\\s*[\\s\\S]*?\u65BD\u8A2DID[:\uFF1A]\\s*${facilityId}`));
    if (idMatch) {
      const beforeId = pageText.substring(
        Math.max(0, pageText.indexOf(`\u65BD\u8A2DID`) - 200),
        pageText.indexOf(`\u65BD\u8A2DID`)
      );
      const lines = beforeId.split(/\n/).map((l) => l.trim()).filter((l) => l.length > 0 && l.length < 100);
      if (lines.length > 0) {
        const candidates = lines.filter(
          (l) => !["\u7DE8\u96C6", "\u30D7\u30EC\u30D3\u30E5\u30FC", "\u6761\u4EF6\u3092\u30AF\u30EA\u30A2", "\u6C42\u4EBA\u60C5\u5831\u3092\u7D5E\u308A\u8FBC\u3080"].includes(l) && !l.startsWith("+") && !l.includes("\u65BD\u8A2D\u306E\u767B\u9332")
        );
        if (candidates.length > 0) {
          facilityName = candidates[candidates.length - 1];
        }
      }
    }
    let address = "";
    const addrMatch = pageText.match(/((?:北海道|東京都|(?:京都|大阪)府|.{2,3}県)\S+)/);
    if (addrMatch) {
      address = addrMatch[1];
    }
    let facilityType = "";
    const typeMatch = pageText.match(/(?:施設ID[:：]\s*\d+[\s\S]*?)(訪問看護ステーション|病院|クリニック|診療所|介護施設|有料老人ホーム|デイサービス|居宅介護|グループホーム|特別養護老人ホーム)/);
    if (typeMatch) {
      facilityType = typeMatch[1];
    }
    console.log(`[FacilityScraper] Basic info: name="${facilityName}", addr="${address}", type="${facilityType}"`);
    return {
      facilityName,
      facilityId,
      address,
      facilityType,
      rawPageText: pageText.substring(0, 5e3).trim()
    };
  }
  async function extractFacilityFromDom(facilityId, facilityName) {
    const navigated = await navigateToFacility(facilityId);
    const facility = {
      facilityName: facilityName || "",
      facilityId,
      address: "",
      facilityType: "",
      representativeMessage: "",
      description: "",
      jobs: [],
      rawPageText: ""
    };
    if (!navigated) {
      facility.rawPageText = "(\u65BD\u8A2D\u30DA\u30FC\u30B8\u3078\u306E\u30CA\u30D3\u30B2\u30FC\u30B7\u30E7\u30F3\u5931\u6557)";
      return facility;
    }
    const basicInfo = extractFacilityBasicInfo(facilityId);
    Object.assign(facility, basicInfo);
    if (facilityName) {
      facility.facilityName = facilityName;
    }
    const activeJobIds = collectActiveJobIdsFromDom();
    console.log(`[FacilityScraper] Facility "${facility.facilityName}": ${activeJobIds.length} active jobs`);
    for (let i = 0; i < activeJobIds.length; i++) {
      if (aborted2) break;
      const previewUrl = `https://customers.job-medley.com/job_offer/${activeJobIds[i]}/confirmation/`;
      try {
        const job = await fetchPreviewPage(previewUrl);
        facility.jobs.push(job);
      } catch (err) {
        console.error(`[FacilityScraper] Failed to fetch preview:`, err);
        facility.jobs.push({
          title: `(\u53D6\u5F97\u5931\u6557: ${activeJobIds[i]})`,
          jobType: "",
          jobDescription: "",
          salary: "",
          benefits: "",
          workingHours: "",
          holidays: "",
          rawText: String(err)
        });
      }
    }
    return facility;
  }
  async function extractFacilityInfo(facilityIds) {
    console.log("[FacilityScraper] Starting extraction for", facilityIds.length, "facilities");
    aborted2 = false;
    const facilityList = extractFacilityList();
    const nameMap = new Map(facilityList.map((f) => [f.facilityId, f.name]));
    const results = [];
    for (let i = 0; i < facilityIds.length; i++) {
      if (aborted2) {
        console.log("[FacilityScraper] Aborted by user");
        break;
      }
      const fId = facilityIds[i];
      const fName = nameMap.get(fId) || "";
      console.log(`[FacilityScraper] Processing facility ${i + 1}/${facilityIds.length}: ${fName} (${fId})`);
      try {
        const facility = await extractFacilityFromDom(fId, fName);
        results.push(facility);
      } catch (err) {
        console.error(`[FacilityScraper] Failed:`, err);
        results.push({
          facilityName: fName || `(\u53D6\u5F97\u5931\u6557: ${fId})`,
          facilityId: fId,
          address: "",
          facilityType: "",
          representativeMessage: "",
          description: "",
          jobs: [],
          rawPageText: String(err)
        });
      }
    }
    console.log("[FacilityScraper] Extraction complete:", results.length, "facilities");
    return results;
  }

  // src/content/index.ts
  init_company_detector();
  init_scout_quota_scraper();

  // src/content/single-send-tracker.ts
  init_scout_quota_scraper();
  var currentMemberId = null;
  var sentFlagForCurrent = false;
  function captureLightProfile(overlay) {
    return {
      member_id: getValueByLabel(overlay, FIELD_LABELS.memberId),
      age: getValueByLabel(overlay, FIELD_LABELS.age),
      qualifications: getValueByLabel(overlay, FIELD_LABELS.qualifications),
      area: getValueByLabel(overlay, FIELD_LABELS.area),
      desired_employment_type: getValueByLabel(overlay, FIELD_LABELS.desiredEmploymentType)
    };
  }
  function isOverlayOpen() {
    const overlay = document.querySelector(".c-side-cover");
    if (!overlay) return false;
    return !overlay.classList.contains("u-is-hidden");
  }
  function hasPostSendModal() {
    const modals = document.querySelectorAll(".c-modal.js-modal");
    for (const modal of modals) {
      if (modal.classList.contains("u-is-hidden")) continue;
      const body = modal.textContent || "";
      if (body.includes("\u30B9\u30AB\u30A6\u30C8\u3092\u9001\u4FE1\u3057\u307E\u3057\u305F")) return true;
    }
    return false;
  }
  var lastProfileSnapshot = null;
  function setupSingleSendTracker() {
    const observer = new MutationObserver(() => {
      const open = isOverlayOpen();
      const memberId = open ? getOverlayMemberId() : null;
      if (open && memberId) {
        if (memberId !== currentMemberId) {
          currentMemberId = memberId;
          sentFlagForCurrent = false;
          lastProfileSnapshot = null;
        }
        if (!sentFlagForCurrent && hasPostSendModal()) {
          sentFlagForCurrent = true;
          const overlay = document.querySelector(".c-side-cover");
          if (overlay) {
            try {
              lastProfileSnapshot = captureLightProfile(overlay);
            } catch (err) {
              console.warn("[single-send] failed to capture profile snapshot", err);
            }
          }
        }
      } else {
        if (currentMemberId && sentFlagForCurrent) {
          if (!isActive()) {
            const memberId2 = currentMemberId;
            console.log(`[single-send] detected manual send complete: ${memberId2}`);
            safeSendMessage({
              type: "CANDIDATE_SENT",
              memberId: memberId2,
              // Phase C: 手動送信を sheets に記録するための補助情報
              manualSendProfile: lastProfileSnapshot,
              sentAt: (/* @__PURE__ */ new Date()).toISOString()
            });
            setTimeout(() => refreshScoutQuota(), 1500);
          }
        }
        currentMemberId = null;
        sentFlagForCurrent = false;
        lastProfileSnapshot = null;
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style"]
    });
  }

  // src/content/index.ts
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id) return false;
      switch (message.type) {
        case "START_EXTRACTION":
          console.log("[Scout Assistant] START_EXTRACTION received, count:", message.count, "startMemberId:", message.startMemberId);
          startExtraction(message.count, message.startMemberId).catch((err) => {
            safeSendMessage({
              type: "EXTRACTION_ERROR",
              error: err.message
            });
          });
          sendResponse({ ok: true });
          return false;
        case "GET_OVERLAY_MEMBER_ID": {
          const memberId = getOverlayMemberId();
          sendResponse({ memberId });
          return false;
        }
        case "FILL_FORM": {
          handleFillForm(message.text, message.memberId, message.searchTerm, message.jobCategory, message.employmentType, message.skipJobOffer, message.categoryKeywords).then(sendResponse);
          return true;
        }
        case "FILL_JOB_OFFER": {
          handleFillJobOffer(message.searchTerm, message.jobCategory, message.employmentType, message.memberId).then(sendResponse);
          return true;
        }
        case "EXTRACT_CONVERSATION": {
          console.log("[Scout Assistant] EXTRACT_CONVERSATION received");
          if (!isMessagePage()) {
            sendResponse({ type: "CONVERSATION_ERROR", error: "\u30E1\u30C3\u30BB\u30FC\u30B8\u30DA\u30FC\u30B8\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044" });
            return false;
          }
          const thread = extractConversation();
          if (thread) {
            sendResponse({ type: "CONVERSATION_DATA", thread });
          } else {
            sendResponse({ type: "CONVERSATION_ERROR", error: "\u30E1\u30C3\u30BB\u30FC\u30B8\u306E\u62BD\u51FA\u306B\u5931\u6557\u3057\u307E\u3057\u305F\u3002\u4F1A\u8A71\u3092\u9078\u629E\u3057\u3066\u304B\u3089\u518D\u5EA6\u304A\u8A66\u3057\u304F\u3060\u3055\u3044\u3002" });
          }
          return false;
        }
        case "EXTRACT_ALL_CONVERSATIONS": {
          console.log("[Scout Assistant] EXTRACT_ALL_CONVERSATIONS received");
          if (!isMessagePage()) {
            sendResponse({ type: "CONVERSATION_ERROR", error: "\u30E1\u30C3\u30BB\u30FC\u30B8\u30DA\u30FC\u30B8\u3092\u958B\u3044\u3066\u304F\u3060\u3055\u3044" });
            return false;
          }
          sendResponse({ ok: true });
          extractAllConversations((msg) => {
            safeSendMessage(msg);
          });
          return false;
        }
        case "STOP_EXTRACTION":
          abort();
          abortBatchExtraction();
          sendResponse({ ok: true });
          return false;
        case "START_CONTINUOUS_SEND":
          start().catch((err) => {
            console.error("[Scout Assistant] Continuous send error:", err);
          });
          sendResponse({ ok: true });
          return false;
        case "STOP_CONTINUOUS_SEND":
          stop();
          sendResponse({ ok: true });
          return false;
        case "SKIP_CURRENT_CANDIDATE":
          skipCurrent();
          sendResponse({ ok: true });
          return false;
        case "RESUME_AFTER_JOB_OFFER":
          resumeAfterJobOfferFix();
          sendResponse({ ok: true });
          return false;
        case "EXTRACT_JOB_OFFERS":
          extractJobOffers().then(sendResponse);
          return true;
        case "EXTRACT_FACILITY_LIST": {
          try {
            const list = extractFacilityList();
            sendResponse({ success: true, facilities: list });
          } catch (err) {
            sendResponse({ success: false, facilities: [], error: err.message });
          }
          return false;
        }
        case "EXTRACT_FACILITY_INFO":
          extractFacilityInfo(message.facilityIds).then((facilities) => sendResponse({ success: true, facilities })).catch((err) => sendResponse({ success: false, facilities: [], error: err.message }));
          return true;
        case "STOP_FACILITY_EXTRACTION":
          abortFacilityExtraction();
          sendResponse({ ok: true });
          return false;
        case "DETECT_COMPANY": {
          detectCompanyFromPage().then((detected) => {
            if (detected) {
              safeSendMessage({ type: "COMPANY_DETECTED", companyId: detected });
            }
            sendResponse({ ok: true, companyId: detected });
          });
          return true;
        }
        default:
          return false;
      }
    }
  );
  setupOverlayObserver();
  setupSingleSendTracker();
  initScoutQuotaScraper();
  setTimeout(async () => {
    const detected = await detectCompanyFromPage();
    if (detected) {
      safeSendMessage({ type: "COMPANY_DETECTED", companyId: detected });
    }
  }, 1e3);
  console.log("[Scout Assistant] Content script loaded");
})();
//# sourceMappingURL=content.js.map
